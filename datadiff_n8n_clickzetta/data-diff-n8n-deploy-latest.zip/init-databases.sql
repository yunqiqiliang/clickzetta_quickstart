-- 初始化生产环境数据库
-- 创建必要的数据库和用户
-- 注意：这些数据库名称是硬编码的，因为 PostgreSQL 初始化脚本不支持环境变量
-- 如果需要修改数据库名称，请同时修改 docker-compose.yml 中的相应配置

-- 创建 N8N 数据库
CREATE DATABASE n8n;

-- 创建 DataDiff 数据库（必须与 POSTGRES_DB 环境变量一致）
CREATE DATABASE datadiff;

-- 创建 DataDiff 应用相关的表
\c datadiff;

CREATE SCHEMA IF NOT EXISTS public;

-- 创建结果存储的 schema
CREATE SCHEMA IF NOT EXISTS data_diff_results;

-- 比对历史表（保留原表用于向后兼容）
CREATE TABLE comparison_history (
    id SERIAL PRIMARY KEY,
    comparison_id UUID UNIQUE NOT NULL,
    source_connection TEXT NOT NULL,
    target_connection TEXT NOT NULL,
    source_table TEXT NOT NULL,
    target_table TEXT NOT NULL,
    comparison_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    execution_time_seconds DECIMAL(10, 3),
    rows_compared INTEGER,
    differences_found INTEGER,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 比对结果汇总表
CREATE TABLE data_diff_results.comparison_summary (
    id SERIAL PRIMARY KEY,
    comparison_id UUID UNIQUE NOT NULL,
    source_connection JSONB NOT NULL,
    target_connection JSONB NOT NULL,
    source_table TEXT NOT NULL,
    target_table TEXT NOT NULL,
    key_columns TEXT[] NOT NULL,
    algorithm VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    execution_time_seconds DECIMAL(10, 3),
    workflow_execution_seconds DECIMAL(10, 3),
    rows_compared INTEGER,
    rows_matched INTEGER,
    rows_different INTEGER,
    match_rate DECIMAL(5, 2),
    sampling_config JSONB,
    column_remapping JSONB,
    where_conditions JSONB,
    status VARCHAR(20) DEFAULT 'pending',
    progress INTEGER DEFAULT 0,
    current_step TEXT,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    result_json JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 差异详情表
CREATE TABLE data_diff_results.comparison_differences (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    key_values JSONB NOT NULL,
    source_values JSONB,
    target_values JSONB,
    difference_type VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.comparison_summary(comparison_id) ON DELETE CASCADE
);

-- 差异详情表（新格式）
CREATE TABLE data_diff_results.difference_details (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    row_key JSONB NOT NULL,
    difference_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    column_name VARCHAR(255),
    source_value TEXT,
    target_value TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.comparison_summary(comparison_id) ON DELETE CASCADE
);

-- 列统计表
CREATE TABLE data_diff_results.column_statistics (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    table_side VARCHAR(10) NOT NULL CHECK (table_side IN ('source', 'target')),
    column_name VARCHAR(255) NOT NULL,
    data_type VARCHAR(100),
    null_count INTEGER,
    null_rate DECIMAL(5, 2),
    total_count INTEGER,
    unique_count INTEGER,
    cardinality DECIMAL(10, 6),
    min_value TEXT,
    max_value TEXT,
    avg_value DECIMAL(20, 6),
    avg_length DECIMAL(10, 2),
    value_distribution JSONB,
    percentiles JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.comparison_summary(comparison_id) ON DELETE CASCADE
);

-- 时间线分析表
CREATE TABLE data_diff_results.timeline_analysis (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    time_column VARCHAR(255) NOT NULL,
    period_type VARCHAR(50) NOT NULL,
    period_start TIMESTAMP NOT NULL,
    period_end TIMESTAMP NOT NULL,
    source_count INTEGER,
    target_count INTEGER,
    matched_count INTEGER,
    difference_count INTEGER,
    match_rate DECIMAL(5, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.comparison_summary(comparison_id) ON DELETE CASCADE
);

-- 性能指标表
CREATE TABLE data_diff_results.performance_metrics (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(20, 6) NOT NULL,
    metric_unit VARCHAR(50),
    metric_context JSONB,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.comparison_summary(comparison_id) ON DELETE CASCADE
);

-- Schema 比对相关表
CREATE TABLE data_diff_results.schema_comparison_summary (
    id SERIAL PRIMARY KEY,
    comparison_id UUID UNIQUE NOT NULL,
    source_connection JSONB NOT NULL,
    target_connection JSONB NOT NULL,
    source_schema VARCHAR(255) NOT NULL,
    target_schema VARCHAR(255) NOT NULL,
    table_differences INTEGER,
    column_differences INTEGER,
    type_differences INTEGER,
    total_differences INTEGER,
    execution_time_seconds DECIMAL(10, 3),
    workflow_execution_seconds DECIMAL(10, 3),
    status VARCHAR(50) DEFAULT 'pending',
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    schemas_identical BOOLEAN DEFAULT false,
    table_filters JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE data_diff_results.schema_table_differences (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    table_name VARCHAR(255) NOT NULL,
    difference_type VARCHAR(50) NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.schema_comparison_summary(comparison_id) ON DELETE CASCADE
);

CREATE TABLE data_diff_results.schema_column_differences (
    id SERIAL PRIMARY KEY,
    comparison_id UUID NOT NULL,
    table_name VARCHAR(255) NOT NULL,
    column_name VARCHAR(255) NOT NULL,
    difference_type VARCHAR(50) NOT NULL,
    source_type VARCHAR(255),
    target_type VARCHAR(255),
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (comparison_id) REFERENCES data_diff_results.schema_comparison_summary(comparison_id) ON DELETE CASCADE
);

-- 告警规则表
CREATE TABLE alert_rules (
    id SERIAL PRIMARY KEY,
    rule_name VARCHAR(100) UNIQUE NOT NULL,
    condition_expression TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL,
    cooldown_seconds INTEGER DEFAULT 300,
    notification_channels JSONB,
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 告警历史表
CREATE TABLE alert_history (
    id SERIAL PRIMARY KEY,
    alert_id UUID UNIQUE NOT NULL,
    rule_name VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    triggered_at TIMESTAMP NOT NULL,
    resolved_at TIMESTAMP,
    message TEXT,
    context JSONB,
    status VARCHAR(20) DEFAULT 'active'
);

-- 系统指标表
CREATE TABLE system_metrics (
    id SERIAL PRIMARY KEY,
    metric_type VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    value DECIMAL(15, 6) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

-- 创建索引以提高查询性能
CREATE INDEX idx_comparison_history_start_time ON comparison_history(start_time);
CREATE INDEX idx_comparison_history_status ON comparison_history(status);
CREATE INDEX idx_alert_history_triggered_at ON alert_history(triggered_at);
CREATE INDEX idx_system_metrics_timestamp ON system_metrics(timestamp);
CREATE INDEX idx_system_metrics_type_name ON system_metrics(metric_type, metric_name);

-- 为 data_diff_results schema 创建索引
CREATE INDEX idx_summary_comparison_id ON data_diff_results.comparison_summary(comparison_id);
CREATE INDEX idx_summary_start_time ON data_diff_results.comparison_summary(start_time);
CREATE INDEX idx_summary_tables ON data_diff_results.comparison_summary(source_table, target_table);
CREATE INDEX idx_differences_comparison_id ON data_diff_results.comparison_differences(comparison_id);
CREATE INDEX idx_details_comparison_id ON data_diff_results.difference_details(comparison_id);
CREATE INDEX idx_details_type_severity ON data_diff_results.difference_details(difference_type, severity);
CREATE INDEX idx_statistics_comparison_id ON data_diff_results.column_statistics(comparison_id);
CREATE INDEX idx_statistics_column ON data_diff_results.column_statistics(comparison_id, table_side, column_name);
CREATE INDEX idx_timeline_comparison_id ON data_diff_results.timeline_analysis(comparison_id);
CREATE INDEX idx_timeline_period ON data_diff_results.timeline_analysis(comparison_id, time_column, period_start);
CREATE INDEX idx_metrics_comparison_id ON data_diff_results.performance_metrics(comparison_id);
CREATE INDEX idx_metrics_name ON data_diff_results.performance_metrics(comparison_id, metric_name);

-- Schema 比对索引
CREATE INDEX idx_schema_summary_comparison_id ON data_diff_results.schema_comparison_summary(comparison_id);
CREATE INDEX idx_schema_table_diff_comparison_id ON data_diff_results.schema_table_differences(comparison_id);
CREATE INDEX idx_schema_column_diff_comparison_id ON data_diff_results.schema_column_differences(comparison_id);

-- 创建视图以便于查询
CREATE VIEW data_diff_results.recent_comparisons AS
SELECT 
    cs.comparison_id,
    cs.source_table,
    cs.target_table,
    cs.algorithm,
    cs.start_time,
    cs.execution_time_seconds,
    cs.rows_compared,
    cs.match_rate,
    cs.rows_different,
    CASE 
        WHEN cs.match_rate >= 99.5 THEN 'Excellent'
        WHEN cs.match_rate >= 95.0 THEN 'Good'
        WHEN cs.match_rate >= 90.0 THEN 'Fair'
        ELSE 'Poor'
    END as match_quality,
    cs.created_at
FROM data_diff_results.comparison_summary cs
ORDER BY cs.start_time DESC
LIMIT 100;

-- 授予权限
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON SCHEMA data_diff_results TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA data_diff_results TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA data_diff_results TO postgres;