# 🚀 Data-Diff N8N 快速部署指南

只需下载一个压缩包，即可在 5 分钟内启动 Data-Diff N8N！

## 📋 前提条件

- 安装 [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- 至少 8GB 内存
- 可用端口：80, 3000, 5678, 8000, 9090（如需 HTTPS，需额外配置）

## 🎯 快速开始

### 1️⃣ 下载部署包

下载 `data-diff-n8n-deploy-latest.zip` 并解压到任意目录。
```cmd
wget https://raw.githubusercontent.com/yunqiqiliang/clickzetta_quickstart/main/datadiff_n8n_clickzetta/data-diff-n8n-deploy-latest.zip
```cmd

### 2️⃣ 检查端口（推荐）

在部署前检查所需端口是否可用：

**Windows:**
```cmd
check-ports.bat
```

**macOS/Linux:**
```bash
./check-ports.sh
```

如果发现端口冲突，请先停止占用的服务。或稍后在运行 `./deploy.sh setup` 后可以编辑 `.env` 文件修改端口配置。

### 3️⃣ 初始化配置

**Windows:**
```cmd
deploy.bat setup
```

**macOS/Linux:**
```bash
./deploy.sh setup
```

此命令会：
- 创建 `.env` 配置文件
- 自动生成安全密码
- 准备部署环境

### 4️⃣ 启动服务

**Windows:**
```cmd
deploy.bat start
```

**macOS/Linux:**
```bash
./deploy.sh start
```

启动时间取决于是否需要下载镜像：
- **首次启动**：10-20 分钟（需要下载所有 Docker 镜像，约 2GB）
- **后续启动**：2-3 分钟（镜像已在本地）

启动过程中会：
1. 自动拉取所有必需的 Docker 镜像（6个服务）
2. 创建并初始化 PostgreSQL 数据库
3. 配置 Grafana 仪表板
4. 启动所有服务并进行健康检查

💡 提示：可以运行 `deploy.sh status` 查看启动进度。

## 🎉 开始使用

访问以下地址：

| 服务 | 地址 | 说明 |
|------|------|------|
| 🏠 主页 | http://localhost | 系统概览和快速导航 |
| 🔄 N8N 工作流 | http://localhost:5678 | 创建和管理数据比对工作流 |
| 📊 API 文档 | http://localhost:8000/docs | RESTful API 接口文档 |
| 📈 Grafana 监控 | http://localhost:3000 | 数据质量和系统监控仪表板 |

登录凭据请查看 `.env` 文件中的密码。

## 🛠️ 常用操作

### 查看服务状态
```bash
# Windows
deploy.bat status

# macOS/Linux
./deploy.sh status
```

### 查看日志
```bash
# 查看所有服务日志
deploy.bat logs

# 查看特定服务日志
deploy.bat logs n8n
```

### 停止服务
```bash
deploy.bat stop
```

### 重启服务
```bash
deploy.bat restart
```

## 📝 配置说明

编辑 `.env` 文件可以修改：

- **端口配置**：如果默认端口被占用
- **密码设置**：修改各服务的访问密码
- **资源限制**：调整 API 工作进程数等

示例：
```env
# 修改 N8N 端口（默认 5678）
N8N_PORT=5679

# 修改 Grafana 端口（默认 3000）
GRAFANA_PORT=3001

# 修改 API 工作进程数（默认 4）
API_WORKERS=8
```

## 🚨 故障排除

### 端口被占用
如果出现端口冲突错误，请编辑 `.env` 文件修改相应端口。

**注意**：在 Linux 上，`check-ports.sh` 可能会误报 443 端口被占用。如果运行：
```bash
sudo netstat -tlnp | grep :443
```
没有输出，说明端口实际可用，可以忽略此警告。

### Docker 未运行
确保 Docker Desktop 已启动并正在运行。

### 服务无法访问
1. 使用 `deploy.bat status` 检查服务状态
2. 使用 `deploy.bat logs` 查看错误日志
3. 确保防火墙允许相应端口访问

### 从 GitHub 下载部署包
如果从 GitHub 仓库下载，请使用 raw 地址而不是 blob 地址：
```bash
# 正确的下载方式
wget https://github.com/yunqiqiliang/clickzetta_quickstart/raw/main/datadiff_n8n_clickzetta/data-diff-n8n-deploy-latest.zip

# 或使用 curl
curl -L -O https://github.com/yunqiqiliang/clickzetta_quickstart/raw/main/datadiff_n8n_clickzetta/data-diff-n8n-deploy-latest.zip
```

## 📚 进阶使用

### 创建第一个比对工作流

1. 访问 N8N (http://localhost:5678)
2. 使用 `.env` 中的凭据登录
3. 创建新工作流
4. 添加 "Data Comparison" 节点
5. 配置源和目标数据库连接
6. 运行工作流查看结果

### 查看监控仪表板

1. 访问 Grafana (http://localhost:3000)
2. 使用 admin 和 `.env` 中的密码登录
3. 打开预配置的仪表板：
   - **业务指标**：查看数据质量和比对结果
   - **系统监控**：查看性能和资源使用情况

## 🆘 需要帮助？

- 📖 查看[完整文档](https://github.com/yunqiqiliang/data-diff-n8n/wiki)
- 🐛 [报告问题](https://github.com/yunqiqiliang/data-diff-n8n/issues)
- 💬 [社区讨论](https://github.com/yunqiqiliang/data-diff-n8n/discussions)

## ⚠️ 安全提示

- 请务必修改 `.env` 文件中的默认密码
- 生产环境建议配置 HTTPS
- 定期备份数据库数据
- 限制服务的网络访问范围

---

© 2024 Data-Diff N8N. All rights reserved.
