# Docker 镜像说明

Data-Diff N8N 使用以下 Docker 镜像：

## 镜像列表

| 镜像名称 | 用途 | 大小（约） |
|---------|------|-----------|
| `czqiliang/datadiff-api:latest` | Data-Diff API 服务 | ~500MB |
| `czqiliang/datadiff-n8n:latest` | N8N 工作流引擎（含自定义节点） | ~800MB |
| `postgres:15-alpine` | PostgreSQL 数据库 | ~240MB |
| `grafana/grafana:latest` | 监控仪表板 | ~350MB |
| `prom/prometheus:latest` | 指标收集 | ~250MB |
| `nginx:alpine` | 反向代理 | ~40MB |

**总计下载大小：约 2.2GB**

## 下载时间估算

- **100 Mbps 网络**：约 3-5 分钟
- **50 Mbps 网络**：约 5-10 分钟
- **10 Mbps 网络**：约 20-30 分钟

## 镜像更新

镜像会定期更新以包含最新功能和安全修复。使用以下命令更新镜像：

```bash
docker-compose pull
docker-compose up -d
```

## 镜像存储位置

Docker 镜像存储在本地磁盘：
- **Windows**: `C:\ProgramData\Docker\`
- **macOS**: `~/Library/Containers/com.docker.docker/Data/`
- **Linux**: `/var/lib/docker/`

## 清理未使用的镜像

释放磁盘空间：
```bash
docker image prune -a
```