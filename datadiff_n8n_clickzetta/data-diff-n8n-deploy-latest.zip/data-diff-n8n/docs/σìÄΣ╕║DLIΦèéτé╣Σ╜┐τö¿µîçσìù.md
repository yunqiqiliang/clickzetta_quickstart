# 华为 Data Lake Insight (DLI) 使用指南

## 概述

Data-Diff N8N 现已支持华为云 Data Lake Insight (DLI) 作为数据源。DLI 是华为云提供的完全托管的数据湖分析服务，支持标准 SQL 对 OBS 中的数据进行查询分析。

## 前提条件

1. **华为云账号**：需要有效的华为云账号
2. **Access Key (AK) 和 Secret Key (SK)**：从华为云控制台获取
3. **项目 ID**：您的华为云项目 ID
4. **DLI 队列**：已创建的 DLI 队列（或使用默认队列）
5. **数据库**：DLI 中已创建的数据库

## 获取连接参数

### 1. 获取 AK/SK

1. 登录[华为云控制台](https://console.huaweicloud.com)
2. 点击右上角用户名，选择"我的凭证"
3. 在"访问密钥"页面，点击"新增访问密钥"
4. 下载并妥善保管生成的 AK 和 SK

### 2. 获取项目 ID

1. 在华为云控制台，进入"我的凭证"
2. 在"API凭证"部分，找到您所在区域的项目 ID

### 3. 确定区域和端点

常用区域和对应的 DLI 端点：

- **华北-北京四**：`cn-north-4` / `dli.cn-north-4.myhuaweicloud.com`
- **华东-上海一**：`cn-east-3` / `dli.cn-east-3.myhuaweicloud.com`
- **华南-广州**：`cn-south-1` / `dli.cn-south-1.myhuaweicloud.com`

## 在 N8N 中配置 DLI 连接

### 1. 添加数据库凭据

1. 在 N8N 工作流编辑器中，添加 **Database Connector** 节点
2. 点击"Select Credential"，选择"Create New"
3. 在"Database Type"下拉框中选择 **"Huawei DLI"**
4. 填写连接参数：

   - **Access Key (AK)**：您的华为云 Access Key
   - **Secret Key (SK)**：您的华为云 Secret Key
   - **Region**：区域代码（如 `cn-north-4`）
   - **Endpoint**：DLI 服务端点（通常会自动填充）
   - **Project ID**：您的项目 ID
   - **Queue**：DLI 队列名称（默认为 `default`）
   - **Database**：要连接的数据库名称（默认为 `default`）
   - **Data Path**：（可选）OBS 路径，用于外部表

5. 点击"Save"保存凭据

### 2. 测试连接

1. 在 Database Connector 节点中，选择刚创建的 DLI 凭据
2. 选择"Operation"为"Test Connection"
3. 执行节点，确认连接成功

## 使用示例

### 1. 列出表

```javascript
// Database Connector 节点配置
{
  "operation": "listTables",
  "credentials": "DLI Connection"
}
```

### 2. 执行查询

```javascript
// Database Connector 节点配置
{
  "operation": "executeQuery",
  "sqlQuery": "SELECT * FROM my_table LIMIT 10",
  "credentials": "DLI Connection"
}
```

### 3. 数据比对

使用 **Data Comparison Dual Input** 节点进行 DLI 与其他数据源的比对：

1. **源数据库**：配置 DLI 连接
2. **目标数据库**：配置其他数据库（如 MySQL、PostgreSQL 等）
3. 选择要比对的表
4. 配置比对选项（主键、比对列等）
5. 执行比对

## 最佳实践

### 1. 队列管理

- 对于大规模查询，建议使用专用队列而非默认队列
- 根据查询复杂度选择合适的队列规格
- 监控队列使用情况，避免资源浪费

### 2. 性能优化

- 使用分区表提高查询性能
- 合理设置查询超时时间
- 对于大表比对，使用采样功能减少数据传输

### 3. 安全建议

- 定期轮换 AK/SK
- 使用最小权限原则，只授予必要的 DLI 权限
- 在生产环境中使用环境变量存储敏感信息

## 常见问题

### Q1: 连接失败，提示"认证失败"

**解决方案**：
1. 检查 AK/SK 是否正确
2. 确认项目 ID 是否匹配
3. 验证账号是否有 DLI 服务权限

### Q2: 查询超时

**解决方案**：
1. 检查队列状态是否正常
2. 增加查询超时时间
3. 优化 SQL 查询语句
4. 考虑使用更高规格的队列

### Q3: 找不到表

**解决方案**：
1. 确认数据库名称是否正确
2. 检查表是否在指定的数据库中
3. 验证用户是否有表的访问权限

### Q4: OBS 外部表访问失败

**解决方案**：
1. 检查 OBS 路径是否正确
2. 确认 DLI 服务有访问 OBS 的权限
3. 验证 OBS 桶的访问策略

## 限制和注意事项

1. **查询限制**：DLI 有查询并发数和数据扫描量限制
2. **数据类型**：某些特殊数据类型可能需要转换
3. **事务支持**：DLI 不支持传统的 ACID 事务
4. **实时性**：DLI 主要用于批量分析，不适合高频实时查询

## 相关资源

- [华为云 DLI 官方文档](https://support.huaweicloud.com/dli/index.html)
- [DLI SQL 语法参考](https://support.huaweicloud.com/sqlref-dli/dli_08_0001.html)
- [DLI 最佳实践](https://support.huaweicloud.com/bestpractice-dli/dli_05_0001.html)

## 技术支持

如遇到问题，请通过以下方式获取帮助：

1. 查看 N8N 节点的错误日志
2. 检查 API 服务日志：`docker logs datadiff-api`
3. 提交 Issue 到项目仓库
4. 联系华为云技术支持（DLI 相关问题）