# 阿里云 MaxCompute 使用指南

本指南介绍如何在 Data-Diff N8N 中使用阿里云 MaxCompute（ODPS）进行数据比对。

## 前提条件

1. **阿里云账号**：需要有阿里云账号并开通 MaxCompute 服务
2. **Access Key**：创建 Access Key ID 和 Access Key Secret
3. **项目权限**：确保 Access Key 有访问目标项目的权限

## 获取连接信息

### 1. 获取 Access Key
1. 登录阿里云控制台
2. 点击右上角头像 → AccessKey 管理
3. 创建 AccessKey（如果没有）
4. 记录 Access Key ID 和 Access Key Secret

### 2. 获取项目信息
1. 进入 MaxCompute 控制台
2. 查看项目列表，记录项目名称
3. 确认项目所在区域的 Endpoint

### 3. Endpoint 列表
常用的 MaxCompute Endpoint：
- 华东1（杭州）：`http://service.cn-hangzhou.maxcompute.aliyun.com/api`
- 华东2（上海）：`http://service.cn-shanghai.maxcompute.aliyun.com/api`
- 华北2（北京）：`http://service.cn-beijing.maxcompute.aliyun.com/api`
- 华南1（深圳）：`http://service.cn-shenzhen.maxcompute.aliyun.com/api`
- 中国（香港）：`http://service.cn-hongkong.maxcompute.aliyun.com/api`
- 新加坡：`http://service.ap-southeast-1.maxcompute.aliyun.com/api`

## 在 N8N 中配置

### 步骤 1：创建数据库连接凭据

1. 在 N8N 工作流编辑器中，添加 **Database Connector** 节点
2. 在 **Credential to connect with** 下拉菜单中，选择 **Create New**
3. **Database Type** 选择 **Alibaba MaxCompute**
4. 填入以下信息：
   - **Access ID**: 你的 Access Key ID
   - **Access Key**: 你的 Access Key Secret
   - **Project**: MaxCompute 项目名称
   - **Endpoint**: 项目所在区域的 Endpoint（如上所示）
5. 点击 **Create** 保存凭据

### 步骤 2：测试连接

1. 在 Database Connector 节点中选择 **Test Connection** 操作
2. 执行节点，确认连接成功

### 步骤 3：执行查询

1. 选择 **Execute Query** 操作
2. 输入 SQL 查询，例如：
   ```sql
   SELECT COUNT(*) FROM your_table_name
   ```
3. 执行节点查看结果

## 数据比对示例

### 比对两个 MaxCompute 项目的表

1. 创建两个 Database Connector 节点，分别连接到不同的项目
2. 添加 Data Comparison 节点
3. 配置比对参数：
   - 选择要比对的表
   - 设置主键列
   - 选择比对列
4. 执行工作流查看比对结果

### SQL 查询示例

```sql
-- 查看所有表
SHOW TABLES;

-- 查看表结构
DESC table_name;

-- 统计表行数
SELECT COUNT(*) FROM table_name;

-- 查询数据样本
SELECT * FROM table_name LIMIT 10;
```

## 注意事项

1. **网络访问**：确保 N8N 服务能够访问阿里云 MaxCompute 的 Endpoint
2. **权限配置**：Access Key 需要有足够的权限（至少包括 List、Describe、Select 权限）
3. **数据量限制**：大数据量查询可能需要较长时间，建议先用 LIMIT 测试
4. **计费说明**：MaxCompute 按扫描数据量计费，请注意控制查询成本

## 故障排除

### 连接失败
- 检查 Access Key 是否正确
- 确认 Endpoint 地址正确
- 验证项目名称无误
- 检查网络连通性

### 查询失败
- 确认表名正确（MaxCompute 表名区分大小写）
- 检查 SQL 语法是否符合 MaxCompute 规范
- 验证账号是否有查询权限

### 性能问题
- 使用分区过滤减少数据扫描量
- 避免使用 SELECT * 查询大表
- 考虑使用采样查询进行测试

## 连接字符串格式

MaxCompute 的连接字符串格式：
```
maxcompute://<access_id>:<access_key>@<endpoint>/<project>
```

例如：
```
maxcompute://LTAI5txxxxxx:xxxxxxxxxxx@service.cn-hangzhou.maxcompute.aliyun.com/api/my_project
```

## 相关资源

- [MaxCompute 官方文档](https://help.aliyun.com/product/27797.html)
- [PyODPS 文档](https://pyodps.readthedocs.io/)
- [MaxCompute SQL 参考](https://help.aliyun.com/document_detail/27860.html)