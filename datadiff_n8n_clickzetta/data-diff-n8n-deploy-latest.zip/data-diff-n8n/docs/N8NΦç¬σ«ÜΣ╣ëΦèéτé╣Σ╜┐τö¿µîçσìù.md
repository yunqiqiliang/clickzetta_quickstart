# Data-Diff N8N 自定义节点使用指南

## 概述

Data-Diff N8N 提供了三个强大的自定义节点，用于执行跨数据库的数据比较、结果获取和系统维护。这些节点支持异步处理，能够处理大规模数据比较任务。

## 节点介绍

### 1. Data Comparison Dual Input（数据比较双输入节点）

这是核心比较节点，用于比较两个数据库之间的数据或表结构差异。

#### 使用场景
- 比较不同环境（开发/测试/生产）的数据一致性
- 数据迁移前后的验证
- 定期的数据质量检查
- 表结构变更的影响分析
- 数据湖（如华为 DLI）与传统数据库的数据同步验证

#### 配置说明

**基础配置：**
1. **Operation（操作类型）**
   - `Compare Table`：比较表数据内容
   - `Compare Schema`：比较表结构定义

2. **Configuration Mode（配置模式）**
   - `Auto`：自动从连接的数据库节点读取配置（推荐）
   - `Manual`：手动输入连接信息

3. **Table Selection（表选择）**
   - `Auto`：自动使用第一个可用表
   - `Specified`：手动指定表名
   - `All`：比较查询结果

**数据比较特定参数：**

| 参数名 | 说明 | 示例 |
|--------|------|------|
| Key Columns | 唯一标识每行的列 | `id` 或 `user_id,created_at` |
| Columns to Compare | 要比较的列，留空比较所有列 | `name,email,status` |
| Where Condition | SQL 过滤条件 | `created_at > '2024-01-01'` |

**高级选项：**

1. **采样配置**（处理大数据集）
   - Enable Sampling：启用采样
   - Sample Type：`Fixed Size`（固定数量）或 `Percentage`（百分比）
   - Sample Method：
     - `DETERMINISTIC`：确定性采样（推荐，结果可重复）
     - `SYSTEM`：系统采样（更快）
     - `BERNOULLI`：行级随机采样

2. **比较算法**
   - `Auto`：自动选择最优算法
   - `JoinDiff`：适用于同一数据库的比较
   - `HashDiff`：适用于跨数据库比较

3. **数据类型处理**
   - Float Tolerance：浮点数容差（如 0.0001）
   - Timestamp Precision：时间戳精度
     - `microsecond`：微秒级
     - `millisecond`：毫秒级
     - `second`：秒级
     - `minute`：分钟级
     - `hour`：小时级
     - `day`：天级
   - Case Sensitive：是否区分大小写
   - JSON Compare Mode：
     - `exact`：完全匹配
     - `normalized`：标准化后比较
     - `semantic`：语义比较
     - `keys_only`：仅比较键

### 2. Data Comparison Result（数据比较结果节点）

用于获取异步比较任务的结果。

#### 配置说明

1. **Comparison ID**
   - 直接连接到 Data Comparison Dual Input 节点时自动获取
   - 或手动输入，支持表达式：`{{ $json.comparison_id }}`

2. **Wait for Completion**
   - 启用：阻塞等待任务完成
   - 禁用：立即返回当前状态

3. **轮询设置**（仅在等待完成时可用）
   - Max Wait Time：最大等待时间（10-3600秒）
   - Poll Interval：检查间隔（1-60秒）

### 3. Data Comparison Maintenance（数据比较维护节点）

用于系统维护和历史数据管理。

#### 操作类型

1. **Clear Materialized Records（清理历史记录）**
   - Record Type：All、Table Comparisons、Schema Comparisons
   - Time Range：All Time、Failed Only、By Date Range
   - Confirm：必须设置为 Yes 才会执行

2. **Get System Statistics（获取系统统计）**
   - 无需参数，返回系统使用统计

3. **Clean Up Failed Tasks（清理失败任务）**
   - Status：Failed、Running (stuck)、Pending (stuck)
   - Stuck Threshold：判定为卡住的小时数

4. **Export Comparison History（导出历史）**
   - Format：JSON 或 CSV
   - Time Period：All、Last 7 days、Last 30 days、Custom
   - Include Details：是否包含详细信息

5. **Database Maintenance（数据库维护）**
   - 执行 VACUUM 和 ANALYZE 优化性能

## 典型工作流示例

### 示例 1：基础数据比较

```
1. PostgreSQL 节点（源数据库）
   ↓
2. Data Comparison Dual Input ← MySQL 节点（目标数据库）
   ↓
3. Data Comparison Result
   ↓
4. 后续处理（如发送通知、生成报告）
```

### 示例 2：定时数据质量检查

```
1. Schedule Trigger（每天凌晨2点）
   ↓
2. 两个数据库连接节点
   ↓
3. Data Comparison Dual Input
   - Operation: Compare Table
   - Key Columns: id
   - Enable Column Statistics: Yes
   ↓
4. Data Comparison Result
   - Wait for Completion: Yes
   - Max Wait Time: 600
   ↓
5. IF 节点（检查差异数量）
   ↓
6. 发送告警邮件（如果有差异）
```

### 示例 3：数据迁移验证

```
1. 源数据库（生产环境）
   ↓
2. Data Comparison Dual Input ← 目标数据库（新环境）
   - Operation: Compare Table
   - Key Columns: 根据表的主键
   - Enable Sampling: Yes（大表）
   - Sample Type: Percentage
   - Sample Percentage: 10
   ↓
3. Data Comparison Result
   ↓
4. 生成验证报告
```

## 最佳实践

### 1. 性能优化

- **大数据集**：启用采样功能，先用小样本验证
- **主键选择**：选择有索引的列作为 Key Columns
- **WHERE 条件**：使用时间范围限制数据量
- **异步处理**：利用异步机制，不要在同步流程中处理大数据

### 2. 错误处理

- 在 Data Comparison Result 后添加错误处理分支
- 设置合理的超时时间
- 定期使用 Maintenance 节点清理失败任务

### 3. 结果处理

- 利用 Column Statistics 进行数据质量分析
- 使用 Timeline Analysis 追踪问题趋势
- 根据 Difference Classification 设置不同级别的告警

### 4. 安全考虑

- 使用 N8N 的凭据管理存储数据库密码
- 限制 WHERE 条件避免全表扫描
- 定期清理历史数据保护隐私

## 常见问题

### Q: 比较任务一直在运行状态？
A: 
1. 检查数据量是否过大，考虑启用采样
2. 使用 Maintenance 节点的 Clean Up Failed Tasks 清理卡住的任务
3. 检查数据库连接是否正常

### Q: 如何处理不同数据类型？
A: 
1. 使用 Float Tolerance 处理浮点数精度问题
2. 调整 Timestamp Precision 处理时间差异
3. 选择合适的 JSON Compare Mode

### Q: 比较结果存储在哪里？
A: 
- 默认存储在 PostgreSQL 数据库的 `data_diff_results` schema 中
- 可以通过 Materialize Results 选项控制是否存储
- 使用 Maintenance 节点管理存储的数据

### Q: 支持哪些数据库类型？
A: 
- 关系型数据库：PostgreSQL、MySQL、Oracle、SQL Server、Vertica
- 分析型数据库：ClickHouse、ClickZetta、DuckDB、Trino、Presto
- 云数据仓库：Snowflake、Huawei DLI
- 详见[支持的数据库列表](./SUPPORTED_DATABASES.md)

## 总结

Data-Diff N8N 自定义节点提供了完整的数据比较解决方案，从执行比较到结果获取再到系统维护。合理使用这些节点可以构建强大的数据质量监控和验证工作流。