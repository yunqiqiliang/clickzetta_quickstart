# 配置说明

## 环境变量与硬编码说明

### 1. 完全可配置的值（通过 .env 文件）

以下值都可以通过 `.env` 文件自定义：

- **数据库配置**
  - `POSTGRES_USER` - PostgreSQL 用户名（默认：postgres）
  - `POSTGRES_PASSWORD` - PostgreSQL 密码（默认：changeme，**必须修改**）
  - `POSTGRES_PORT` - PostgreSQL 端口（默认：5432）

- **服务端口**
  - `API_PORT` - API 服务端口（默认：8000）
  - `N8N_PORT` - N8N 端口（默认：5678）
  - `GRAFANA_PORT` - Grafana 端口（默认：3000）
  - `PROMETHEUS_PORT` - Prometheus 端口（默认：9090）
  - `HTTP_PORT` - Nginx HTTP 端口（默认：80）
  - `HTTPS_PORT` - Nginx HTTPS 端口（默认：443）

- **认证信息**
  - `N8N_BASIC_AUTH_USER` - N8N 用户名（默认：admin）
  - `N8N_BASIC_AUTH_PASSWORD` - N8N 密码（默认：changeme，**必须修改**）
  - `GRAFANA_USER` - Grafana 用户名（默认：admin）
  - `GRAFANA_PASSWORD` - Grafana 密码（默认：changeme，**必须修改**）

### 2. 部分硬编码的值

以下值在某些地方是硬编码的，修改时需要注意：

#### 数据库名称
- **硬编码位置**：`init-databases.sql`
- **原因**：PostgreSQL 初始化脚本不支持环境变量替换
- **影响**：
  - 数据库 `datadiff` 必须与 `POSTGRES_DB` 环境变量一致
  - 数据库 `n8n` 是硬编码的
- **修改方法**：如需修改，需要同时修改：
  1. `.env` 文件中的 `POSTGRES_DB`
  2. `init-databases.sql` 中的数据库名称
  3. `docker-compose.yml` 中的相关引用

#### 内部服务名称
- **硬编码位置**：各配置文件中的服务间通信
- **示例**：
  - `prometheus.yml` 中的 `data-diff-api:8000`
  - `datasources.yml` 中的 `http://prometheus:9090`
  - `nginx.conf` 中的服务代理配置
- **原因**：Docker Compose 网络内部服务发现
- **注意**：这些是内部通信地址，不影响外部访问端口

### 3. 不建议修改的值

以下值虽然可以修改，但不建议：

- `TZ=Asia/Shanghai` - 时区设置，可根据需要修改
- `API_WORKERS=4` - API 工作进程数，根据服务器性能调整
- `LOG_LEVEL=INFO` - 日志级别，调试时可改为 DEBUG

### 4. 安全建议

1. **必须修改的密码**：
   - `POSTGRES_PASSWORD`
   - `N8N_BASIC_AUTH_PASSWORD`
   - `GRAFANA_PASSWORD`

2. **生产环境建议**：
   - 使用强密码（至少 16 位，包含大小写字母、数字和特殊字符）
   - 定期更换密码
   - 不要在版本控制中提交包含真实密码的 `.env` 文件

3. **端口安全**：
   - 考虑修改默认端口以增加安全性
   - 使用防火墙限制端口访问
   - 生产环境建议只开放 80 和 443 端口

### 5. 故障排除

如果修改配置后服务无法正常工作：

1. 检查 `.env` 文件语法是否正确
2. 确保没有端口冲突
3. 运行 `docker-compose down -v` 清理旧数据后重试
4. 查看日志：`docker-compose logs [服务名]`