#!/bin/bash
# 检查实际的环境变量传递情况

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== 环境变量检查工具 ===${NC}"
echo ""

# 1. 检查 .env 文件
echo -e "${BLUE}1. 检查 .env 文件内容:${NC}"
if [ -f .env ]; then
    echo "POSTGRES_PASSWORD 设置:"
    grep "POSTGRES_PASSWORD=" .env | head -1
    echo ""
    echo "所有 PostgreSQL 相关变量:"
    grep -E "^POSTGRES_" .env
else
    echo -e "${RED}✗ .env 文件不存在${NC}"
    exit 1
fi
echo ""

# 2. 检查 docker-compose 解析后的配置
echo -e "${BLUE}2. Docker Compose 解析后的环境变量:${NC}"
echo "PostgreSQL 服务:"
docker-compose config | grep -A 20 "postgres:" | grep -E "(POSTGRES_|environment:)" || true
echo ""
echo "API 服务:"
docker-compose config | grep -A 30 "data-diff-api:" | grep -E "(DB_|DATABASE_|environment:)" || true
echo ""
echo "N8N 服务:"
docker-compose config | grep -A 30 "n8n:" | grep -E "(DB_|environment:)" || true
echo ""

# 3. 检查运行中容器的实际环境变量
echo -e "${BLUE}3. 运行中容器的实际环境变量:${NC}"

# PostgreSQL
echo "PostgreSQL 容器:"
POSTGRES_CONTAINER=$(docker-compose ps -q postgres 2>/dev/null)
if [ -n "$POSTGRES_CONTAINER" ]; then
    echo "POSTGRES_PASSWORD:"
    docker exec $POSTGRES_CONTAINER env | grep POSTGRES_PASSWORD || echo "未找到"
else
    echo -e "${YELLOW}PostgreSQL 容器未运行${NC}"
fi
echo ""

# API
echo "API 容器:"
API_CONTAINER=$(docker-compose ps -q data-diff-api 2>/dev/null)
if [ -n "$API_CONTAINER" ]; then
    echo "DB_ 相关变量:"
    docker exec $API_CONTAINER env | grep ^DB_ | sort || echo "未找到"
    echo "DATABASE_URL:"
    docker exec $API_CONTAINER env | grep DATABASE_URL || echo "未找到"
else
    echo -e "${YELLOW}API 容器未运行${NC}"
fi
echo ""

# N8N
echo "N8N 容器:"
N8N_CONTAINER=$(docker-compose ps -q n8n 2>/dev/null)
if [ -n "$N8N_CONTAINER" ]; then
    echo "DB_POSTGRESDB_ 相关变量:"
    docker exec $N8N_CONTAINER env | grep DB_POSTGRESDB_ | sort || echo "未找到"
else
    echo -e "${YELLOW}N8N 容器未运行${NC}"
fi
echo ""

# 4. 测试实际连接
echo -e "${BLUE}4. 测试数据库连接:${NC}"
if [ -f .env ]; then
    source .env
    echo "尝试使用 .env 中的密码: $POSTGRES_PASSWORD"
    
    # 测试连接
    if PGPASSWORD=$POSTGRES_PASSWORD docker exec -e PGPASSWORD=$POSTGRES_PASSWORD $POSTGRES_CONTAINER psql -U postgres -c "SELECT 1;" >/dev/null 2>&1; then
        echo -e "${GREEN}✓ 可以使用 .env 密码连接${NC}"
    else
        echo -e "${RED}✗ 无法使用 .env 密码连接${NC}"
        
        # 尝试默认密码
        if PGPASSWORD=changeme docker exec -e PGPASSWORD=changeme $POSTGRES_CONTAINER psql -U postgres -c "SELECT 1;" >/dev/null 2>&1; then
            echo -e "${YELLOW}! 但可以使用 'changeme' 连接${NC}"
        fi
    fi
fi