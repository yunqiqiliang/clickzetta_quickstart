# Prometheus 监控使用指南

## 概述

Data-Diff N8N 集成了 Prometheus 监控系统，用于收集和存储系统指标。Prometheus 提供了详细的性能监控、业务指标追踪和系统健康状态监控。

## 访问 Prometheus

- **访问地址**：http://localhost/prometheus/
- **无需认证**：默认配置下无需登录

## 指标概览

### 1. API 性能指标

#### datadiff_api_request_duration_seconds
API 请求响应时间（秒）

**标签：**
- `method`：HTTP 方法（GET、POST 等）
- `endpoint`：API 端点路径
- `status`：HTTP 状态码

**查询示例：**
```promql
# 查看 API 平均响应时间
rate(datadiff_api_request_duration_seconds_sum[5m]) / rate(datadiff_api_request_duration_seconds_count[5m])

# 查看 99 分位响应时间
histogram_quantile(0.99, rate(datadiff_api_request_duration_seconds_bucket[5m]))
```

#### datadiff_api_request_total
API 请求总数

**查询示例：**
```promql
# 每秒请求率
rate(datadiff_api_request_total[5m])

# 错误率
rate(datadiff_api_request_total{status=~"5.."}[5m])
```

### 2. 数据比较业务指标

#### datadiff_comparison_duration_seconds
数据比较执行时间（秒）

**标签：**
- `comparison_type`：比较类型（table/schema）
- `algorithm`：使用的算法（hashdiff/joindiff/auto）
- `status`：执行状态（completed/failed）
- `source_type`：源数据库类型
- `target_type`：目标数据库类型

**查询示例：**
```promql
# 平均比较执行时间
avg(rate(datadiff_comparison_duration_seconds_sum[1h])) by (comparison_type)

# 按数据库类型统计执行时间
avg(datadiff_comparison_duration_seconds) by (source_type, target_type)
```

#### datadiff_comparison_differences_total
发现的数据差异数量

**标签：**
- `comparison_type`：比较类型
- `table_name`：表名
- `database_type`：数据库类型

**查询示例：**
```promql
# 差异数量趋势
rate(datadiff_comparison_differences_total_sum[1h])

# 按表统计差异
sum(datadiff_comparison_differences_total_sum) by (table_name)
```

#### datadiff_rows_compared_total
比较的总行数

**查询示例：**
```promql
# 数据处理速率（行/秒）
rate(datadiff_rows_compared_total_sum[5m])

# 累计处理数据量
sum(datadiff_rows_compared_total_sum)
```

### 3. 数据质量指标

#### datadiff_column_null_rate
列的空值率

**标签：**
- `table_name`：表名
- `column_name`：列名
- `database_type`：数据库类型

**查询示例：**
```promql
# 空值率超过 10% 的列
datadiff_column_null_rate > 0.1

# 按表统计平均空值率
avg(datadiff_column_null_rate) by (table_name)
```

#### datadiff_data_quality_score
数据质量评分（0-100）

**标签：**
- `table_name`：表名
- `check_type`：检查类型

### 4. 系统资源指标

#### datadiff_memory_usage_bytes
内存使用量（字节）

**查询示例：**
```promql
# 内存使用量（MB）
datadiff_memory_usage_bytes / 1024 / 1024

# 内存使用趋势
rate(datadiff_memory_usage_bytes[5m])
```

#### datadiff_cpu_usage_percent
CPU 使用率（百分比）

#### datadiff_db_connections_active
活跃的数据库连接数

**标签：**
- `database_type`：数据库类型
- `connection_pool`：连接池名称

### 5. 特殊指标

#### datadiff_comparison_memory_peak_mb
比较任务的峰值内存使用（MB）

**标签：**
- `comparison_id`：比较任务 ID
- `comparison_type`：比较类型

#### datadiff_feature_usage_total
功能使用统计

**标签：**
- `feature_name`：功能名称
- `parameter_name`：参数名称

## 常用查询示例

### 监控仪表板查询

1. **系统健康状态**
```promql
# API 可用性
up{job="datadiff-api"}

# 最近 5 分钟错误率
sum(rate(datadiff_api_request_total{status=~"5.."}[5m])) / sum(rate(datadiff_api_request_total[5m]))
```

2. **性能监控**
```promql
# P95 响应时间
histogram_quantile(0.95, sum(rate(datadiff_api_request_duration_seconds_bucket[5m])) by (le))

# 比较任务成功率
sum(datadiff_comparison_total{status="completed"}) / sum(datadiff_comparison_total)
```

3. **业务指标**
```promql
# 今日比较任务数
increase(datadiff_comparison_total[1d])

# 发现的数据差异趋势
sum(rate(datadiff_comparison_differences_total_sum[1h])) by (table_name)
```

4. **资源使用**
```promql
# 内存使用率（假设 8GB 总内存）
datadiff_memory_usage_bytes / (8 * 1024 * 1024 * 1024) * 100

# 数据库连接池使用率
datadiff_db_connections_active / (datadiff_db_connections_active + datadiff_db_connections_idle)
```

## 告警规则示例

在 Prometheus 中配置告警规则：

```yaml
groups:
  - name: datadiff_alerts
    rules:
      - alert: HighErrorRate
        expr: sum(rate(datadiff_api_request_total{status=~"5.."}[5m])) / sum(rate(datadiff_api_request_total[5m])) > 0.05
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "API 错误率过高"
          description: "错误率超过 5%，当前值: {{ $value | humanizePercentage }}"
      
      - alert: SlowAPIResponse
        expr: histogram_quantile(0.95, rate(datadiff_api_request_duration_seconds_bucket[5m])) > 2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "API 响应缓慢"
          description: "P95 响应时间超过 2 秒"
      
      - alert: HighMemoryUsage
        expr: datadiff_memory_usage_bytes / (8 * 1024 * 1024 * 1024) > 0.9
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "内存使用率过高"
          description: "内存使用率超过 90%"
```

## 数据保留策略

默认配置：
- 数据保留时间：30 天
- 采集间隔：
  - API 指标：60 秒
  - 系统指标：15 秒

## 与 Grafana 集成

Prometheus 已配置为 Grafana 的数据源，您可以：
1. 在 Grafana 中创建自定义仪表板
2. 使用上述查询创建图表
3. 设置告警通知

## 最佳实践

1. **定期检查关键指标**
   - API 错误率
   - 响应时间
   - 内存使用率
   - 比较任务成功率

2. **设置合理的告警阈值**
   - 根据实际业务需求调整
   - 避免告警疲劳

3. **使用标签进行细粒度监控**
   - 按表名监控数据质量
   - 按数据库类型监控性能
   - 按端点监控 API 使用情况

4. **定期清理历史数据**
   - 默认保留 30 天
   - 可根据需要调整保留策略

## 故障排查

### 问题：Prometheus 无法抓取指标
解决：
1. 检查 API 服务是否正常运行
2. 访问 http://localhost/api/v1/metrics 确认指标端点可用
3. 检查 Prometheus 配置中的 targets

### 问题：指标数据缺失
解决：
1. 检查相关功能是否被使用
2. 确认指标收集代码是否正确执行
3. 查看 API 日志是否有错误

## 总结

Prometheus 为 Data-Diff N8N 提供了全面的监控能力。通过合理使用这些指标，您可以：
- 实时监控系统健康状态
- 追踪业务指标变化
- 及时发现和解决问题
- 优化系统性能