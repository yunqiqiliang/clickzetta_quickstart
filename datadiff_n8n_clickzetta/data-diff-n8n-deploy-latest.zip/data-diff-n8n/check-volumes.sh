#!/bin/bash
# Data-Diff N8N Volume 冲突检查脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 打印函数
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# 定义项目使用的 volumes
PROJECT_VOLUMES=(
    "postgres_data"
    "n8n_data"
    "grafana_data"
    "prometheus_data"
)

# 获取 compose 项目名称
get_project_name() {
    if [ -f .env ] && grep -q "COMPOSE_PROJECT_NAME" .env; then
        source .env
        echo "${COMPOSE_PROJECT_NAME:-datadiff}"
    else
        echo "datadiff"
    fi
}

# 主函数
main() {
    print_info "检查 Docker Volume 冲突"
    echo ""
    
    # 获取项目名称
    PROJECT_NAME=$(get_project_name)
    print_info "项目名称: $PROJECT_NAME"
    echo ""
    
    # 获取所有现有的 Docker volumes
    existing_volumes=$(docker volume ls --format "{{.Name}}" 2>/dev/null || true)
    
    local conflicts=0
    local conflict_volumes=()
    
    print_info "检查 Volume 状态..."
    echo ""
    
    for volume in "${PROJECT_VOLUMES[@]}"; do
        # Docker Compose 会在 volume 名称前加上项目名称
        full_volume_name="${PROJECT_NAME}_${volume}"
        
        if echo "$existing_volumes" | grep -q "^${full_volume_name}$"; then
            # 检查 volume 是否被其他容器使用
            containers_using=$(docker ps -a --filter "volume=${full_volume_name}" --format "{{.Names}}" 2>/dev/null || true)
            
            if [ -n "$containers_using" ]; then
                # 检查是否是我们项目的容器
                our_containers=true
                while IFS= read -r container; do
                    if [[ ! "$container" =~ ^datadiff- ]]; then
                        our_containers=false
                        break
                    fi
                done <<< "$containers_using"
                
                if [ "$our_containers" = true ]; then
                    print_success "Volume $volume 存在（属于本项目）"
                else
                    print_error "Volume $volume 被其他容器使用！"
                    echo "    使用的容器: "
                    echo "$containers_using" | sed 's/^/      - /'
                    conflicts=$((conflicts + 1))
                    conflict_volumes+=("$full_volume_name")
                fi
            else
                print_success "Volume $volume 存在（未使用）"
            fi
        else
            print_info "Volume $volume 不存在（将在启动时创建）"
        fi
    done
    
    echo ""
    
    # 检查网络冲突
    print_info "检查 Docker 网络..."
    network_name="${PROJECT_NAME}_datadiff-network"
    
    if docker network ls --format "{{.Name}}" | grep -q "^${network_name}$"; then
        print_success "网络 datadiff-network 存在"
    else
        print_info "网络 datadiff-network 不存在（将在启动时创建）"
    fi
    
    echo ""
    
    # 总结
    if [ $conflicts -gt 0 ]; then
        print_error "发现 $conflicts 个 Volume 冲突！"
        echo ""
        print_warning "解决方案："
        echo "  1. 停止使用这些 volume 的容器："
        echo "     docker stop <container_name>"
        echo ""
        echo "  2. 或者删除冲突的 volumes（会丢失数据！）："
        for vol in "${conflict_volumes[@]}"; do
            echo "     docker volume rm $vol"
        done
        echo ""
        echo "  3. 或者修改 .env 文件中的 COMPOSE_PROJECT_NAME"
        exit 1
    else
        print_success "没有发现 Volume 冲突！"
        
        # 检查是否有旧数据
        local has_data=false
        for volume in "${PROJECT_VOLUMES[@]}"; do
            full_volume_name="${PROJECT_NAME}_${volume}"
            if echo "$existing_volumes" | grep -q "^${full_volume_name}$"; then
                has_data=true
                break
            fi
        done
        
        if [ "$has_data" = true ]; then
            echo ""
            print_warning "发现已存在的 volumes，启动时将使用现有数据"
            print_info "如需全新安装，可以运行："
            echo "  docker-compose down -v"
            echo "  ./deploy.sh setup"
            echo "  ./deploy.sh start"
        fi
        
        echo ""
        print_info "可以安全地启动服务"
        exit 0
    fi
}

# 执行主函数
main