#!/bin/bash
# Data-Diff N8N 简化部署脚本

set -e

# 定义颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 显示帮助信息
show_help() {
    echo "Data-Diff N8N 部署脚本"
    echo ""
    echo "用法: ./deploy.sh [命令]"
    echo ""
    echo "常用命令:"
    echo "  start    启动服务"
    echo "  stop     停止服务"
    echo "  restart  重启服务"
    echo "  status   查看服务状态"
    echo "  logs     查看服务日志"
    echo ""
    echo "初始化和维护:"
    echo "  setup    初始化环境配置（首次部署使用）"
    echo "  init     完整启动（包含数据库初始化检查）"
    echo "  clean    清理所有数据（危险操作）"
    echo ""
    echo "帮助:"
    echo "  help     显示此帮助信息"
    echo ""
    echo "提示: 日常使用 start/stop/restart 即可，首次部署请先运行 setup 和 init"
}

# 检查 Docker 是否安装
check_docker() {
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}错误: Docker 未安装${NC}"
        echo "请访问 https://www.docker.com/products/docker-desktop/ 安装 Docker"
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        echo -e "${RED}错误: Docker 未运行${NC}"
        echo "请启动 Docker Desktop"
        exit 1
    fi
}

# 初始化设置
setup() {
    echo -e "${BLUE}正在初始化 Data-Diff N8N...${NC}"
    
    # 检查 .env 文件
    if [ -f .env ]; then
        echo -e "${YELLOW}警告: .env 文件已存在${NC}"
        read -p "是否覆盖现有配置？ (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "保留现有配置"
            return
        fi
    fi
    
    # 复制环境配置文件
    cp .env.example .env
    echo -e "${GREEN}✓ 已创建 .env 文件${NC}"
    
    # 生成随机密码
    generate_password() {
        openssl rand -base64 12 | tr -d "=+/" | cut -c1-16
    }
    
    # 生成一个密码并用于所有服务
    GENERATED_PASSWORD=$(generate_password)
    
    # 更新密码
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/changeme/${GENERATED_PASSWORD}/g" .env
    else
        # Linux
        sed -i "s/changeme/${GENERATED_PASSWORD}/g" .env
    fi
    
    echo -e "${GREEN}✓ 已生成安全密码${NC}"
    echo ""
    echo -e "${YELLOW}重要提示:${NC}"
    echo "1. 请检查 .env 文件中的配置"
    echo "2. 确保端口未被占用（80, 443, 3000, 5678, 8000, 9090）"
    echo "3. 首次启动使用 './deploy.sh init'"
    echo "4. 日常启动使用 './deploy.sh start'"
}

# 完整初始化启动（首次部署使用）
init() {
    echo -e "${BLUE}正在启动 Data-Diff N8N 服务...${NC}"
    
    check_docker
    
    # 检查 .env 文件
    if [ ! -f .env ]; then
        echo -e "${RED}错误: 未找到 .env 文件${NC}"
        echo "请先运行 './deploy.sh setup'"
        exit 1
    fi
    
    # 检查 volume 冲突
    if [ -f ./check-volumes.sh ]; then
        echo -e "${BLUE}检查 Docker volumes...${NC}"
        ./check-volumes.sh || {
            echo -e "${RED}Volume 检查失败，请解决冲突后再试${NC}"
            exit 1
        }
        echo ""
    fi
    
    # 检查是否为首次运行
    FIRST_RUN=false
    if [ ! -f ".docker_images_downloaded" ]; then
        FIRST_RUN=true
        echo -e "${BLUE}首次启动检测：需要下载 Docker 镜像${NC}"
        echo "预计下载大小：约 2GB"
        echo "预计时间：10-20 分钟（取决于网络速度）"
        echo ""
    fi
    
    # 检查是否有旧的 N8N 配置
    if docker volume ls | grep -q "n8n_data"; then
        echo -e "${YELLOW}检测到已存在的 N8N 数据卷${NC}"
        echo "这可能包含旧的数据库连接配置"
        read -p "是否清理 N8N 配置以使用新密码？(y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "正在清理 N8N 配置..."
            docker-compose stop n8n 2>/dev/null || true
            docker volume rm $(docker volume ls -q | grep n8n_data) 2>/dev/null || true
            echo -e "${GREEN}✓ 已清理 N8N 配置${NC}"
        fi
    fi
    
    # 验证环境变量
    echo -e "${BLUE}验证配置...${NC}"
    source .env
    if [ -z "$POSTGRES_PASSWORD" ] || [ "$POSTGRES_PASSWORD" = "changeme" ]; then
        echo -e "${RED}错误: PostgreSQL 密码未正确设置${NC}"
        echo "请检查 .env 文件中的 POSTGRES_PASSWORD"
        exit 1
    fi
    
    # 启动服务
    echo -e "${BLUE}正在拉取镜像并启动服务...${NC}"
    
    # 先启动 PostgreSQL
    echo "启动 PostgreSQL..."
    docker-compose up -d postgres
    
    # 等待 PostgreSQL 完全就绪
    echo "等待 PostgreSQL 初始化..."
    sleep 5
    MAX_ATTEMPTS=30
    ATTEMPT=0
    while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
        if docker-compose exec -T postgres pg_isready -U postgres >/dev/null 2>&1; then
            echo -e "${GREEN}✓ PostgreSQL 已就绪${NC}"
            break
        fi
        ATTEMPT=$((ATTEMPT + 1))
        echo -n "."
        sleep 2
    done
    
    if [ $ATTEMPT -eq $MAX_ATTEMPTS ]; then
        echo -e "${RED}PostgreSQL 启动超时${NC}"
        exit 1
    fi
    
    # 验证 PostgreSQL 密码
    echo "验证数据库连接..."
    if PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -c "SELECT 1;" >/dev/null 2>&1; then
        echo -e "${GREEN}✓ 数据库密码验证成功${NC}"
    else
        echo -e "${RED}✗ 数据库密码验证失败${NC}"
        echo ""
        echo "这通常是因为 PostgreSQL 数据卷中保存了旧密码"
        echo ""
        echo -e "${YELLOW}解决方案：${NC}"
        echo "1. 停止所有服务并清理数据（推荐）："
        echo "   ./deploy.sh clean"
        echo "   ./deploy.sh setup"
        echo "   ./deploy.sh start"
        echo ""
        echo "2. 或者运行环境变量检查工具了解详情："
        echo "   ./check-env-vars.sh"
        exit 1
    fi
    
    # 检查数据库初始化状态（仅用于验证）
    echo "检查数据库初始化状态..."
    
    # 如果是首次运行，给 PostgreSQL 更多时间执行初始化脚本
    if [ "$FIRST_RUN" = true ]; then
        echo "首次运行，等待数据库初始化脚本执行..."
        sleep 10
    else
        sleep 3
    fi
    
    # 检查关键数据库是否存在
    if ! PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -c "SELECT 1 FROM pg_database WHERE datname = 'datadiff';" | grep -q "1 row"; then
        echo -e "${YELLOW}数据库正在初始化，请稍等...${NC}"
        # 给初始化脚本更多时间
        sleep 5
        
        # 再次检查
        if ! PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -c "SELECT 1 FROM pg_database WHERE datname = 'datadiff';" | grep -q "1 row"; then
            echo -e "${RED}✗ 数据库初始化失败：datadiff 数据库不存在${NC}"
            echo "可能原因："
            echo "1. PostgreSQL 数据卷包含旧数据"
            echo "2. init-databases.sql 文件有错误"
            echo ""
            echo "建议运行: ./deploy.sh clean 后重新启动"
            exit 1
        fi
    fi
    
    # 检查关键表是否存在
    echo "验证数据库表结构..."
    if ! PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -d datadiff -c "\dt data_diff_results.*" 2>/dev/null | grep -q "comparison_summary"; then
        echo -e "${YELLOW}数据库表未初始化，正在创建...${NC}"
        
        # 手动执行初始化脚本
        docker-compose exec -T postgres psql -U postgres < init-databases.sql 2>&1 | grep -v "already exists"
        
        sleep 3
        
        # 最终检查
        if ! PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -d datadiff -c "\dt data_diff_results.*" 2>/dev/null | grep -q "comparison_summary"; then
            echo -e "${RED}✗ 数据库表初始化失败${NC}"
            echo "建议运行: ./deploy.sh clean 后重新启动"
            exit 1
        fi
    fi
    
    echo -e "${GREEN}✓ 数据库初始化验证通过${NC}"
    
    # 启动其他服务
    echo "启动其他服务..."
    docker-compose up -d
    
    if [ "$FIRST_RUN" = true ]; then
        touch .docker_images_downloaded
    fi
    
    echo -e "${GREEN}✓ 服务正在启动${NC}"
    echo ""
    
    if [ "$FIRST_RUN" = true ]; then
        echo "⏱️  首次启动预计需要 10-20 分钟"
        echo "   包括："
        echo "   - 下载 6 个 Docker 镜像"
        echo "   - 初始化 PostgreSQL 数据库"
        echo "   - 配置 Grafana 仪表板"
        echo "   - 启动健康检查"
    else
        echo "⏱️  服务启动预计需要 2-3 分钟"
    fi
    echo ""
    echo "访问地址:"
    echo "  主页: http://localhost"
    echo "  N8N: http://localhost:5678"
    echo "  API: http://localhost:8000/docs"
    echo "  Grafana: http://localhost:3000"
    echo ""
    echo "使用 './deploy.sh status' 查看服务状态"
}

# 完全停止（移除容器）
stop-all() {
    echo -e "${BLUE}正在停止并移除 Data-Diff N8N 容器...${NC}"
    docker-compose down
    echo -e "${GREEN}✓ 服务已停止并移除容器${NC}"
}

# 重启服务（日常使用）
restart() {
    echo -e "${BLUE}正在重启 Data-Diff N8N 服务...${NC}"
    docker-compose restart
    echo -e "${GREEN}✓ 服务重启命令已执行${NC}"
    echo ""
    echo "服务重启中，请稍候..."
    echo "使用 './deploy.sh status' 查看服务状态"
}

# 完整重启（包含初始化检查）
restart-full() {
    stop-all
    sleep 2
    init
}

# 查看服务状态
status() {
    echo -e "${BLUE}Data-Diff N8N 服务状态:${NC}"
    echo ""
    docker-compose ps
}

# 查看日志
logs() {
    if [ -z "$2" ]; then
        docker-compose logs -f --tail=100
    else
        docker-compose logs -f --tail=100 $2
    fi
}

# 启动服务（日常使用）
start() {
    echo -e "${BLUE}正在快速启动 Data-Diff N8N 服务...${NC}"
    
    check_docker
    
    # 检查 .env 文件
    if [ ! -f .env ]; then
        echo -e "${RED}错误: 未找到 .env 文件${NC}"
        echo "请先运行 './deploy.sh setup'"
        exit 1
    fi
    
    # 直接启动所有服务
    docker-compose up -d
    
    echo -e "${GREEN}✓ 服务启动命令已执行${NC}"
    echo ""
    echo "服务启动中，请稍候..."
    echo ""
    echo "访问地址:"
    echo "  主页: http://localhost"
    echo "  N8N: http://localhost:5678"
    echo "  API: http://localhost:8000/docs"
    echo "  Grafana: http://localhost:3000"
    echo ""
    echo "使用 './deploy.sh status' 查看服务状态"
    echo "使用 './deploy.sh logs' 查看服务日志"
}

# 停止服务（日常使用）
stop() {
    echo -e "${BLUE}正在快速停止 Data-Diff N8N 服务...${NC}"
    docker-compose stop
    echo -e "${GREEN}✓ 服务已停止${NC}"
}

# 清理数据
clean() {
    echo -e "${RED}警告: 此操作将删除所有数据！${NC}"
    read -p "确定要继续吗？ (yes/NO): " -r
    if [[ $REPLY == "yes" ]]; then
        docker-compose down -v
        rm -f .docker_images_downloaded
        echo -e "${GREEN}✓ 已清理所有数据${NC}"
    else
        echo "操作已取消"
    fi
}

# 主程序
case "$1" in
    setup)
        setup
        ;;
    init)
        init
        ;;
    start)
        start
        ;;
    stop)
        stop
        ;;
    stop-all)
        stop-all
        ;;
    restart)
        restart
        ;;
    restart-full)
        restart-full
        ;;
    status)
        status
        ;;
    logs)
        logs "$@"
        ;;
    clean)
        clean
        ;;
    help|"")
        show_help
        ;;
    *)
        echo -e "${RED}错误: 未知命令 '$1'${NC}"
        echo ""
        show_help
        exit 1
        ;;
esac