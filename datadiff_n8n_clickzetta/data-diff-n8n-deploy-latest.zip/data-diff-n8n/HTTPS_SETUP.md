# HTTPS 配置指南

如果您需要启用 HTTPS 访问，请按照以下步骤配置。

## 方案 1：使用自签名证书（适合内网）

### 1. 生成自签名证书
```bash
# 创建证书目录
mkdir -p ssl

# 生成私钥和证书
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ssl/nginx.key \
  -out ssl/nginx.crt \
  -subj "/C=CN/ST=State/L=City/O=Organization/CN=data-diff.local"
```

### 2. 创建 HTTPS 版本的 nginx.conf
```bash
cp nginx.conf nginx-https.conf
```

编辑 `nginx-https.conf`，添加 HTTPS 服务器块：

```nginx
server {
    listen 443 ssl;
    server_name _;
    
    ssl_certificate /etc/nginx/ssl/nginx.crt;
    ssl_certificate_key /etc/nginx/ssl/nginx.key;
    
    # SSL 配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # 其他 location 配置与 HTTP 相同
    # ...
}

# HTTP 重定向到 HTTPS
server {
    listen 80;
    server_name _;
    return 301 https://$server_name$request_uri;
}
```

### 3. 更新 docker-compose.yml
```yaml
nginx:
  volumes:
    - ./nginx-https.conf:/etc/nginx/nginx.conf:ro
    - ./ssl:/etc/nginx/ssl:ro
    - ./index.html:/usr/share/nginx/html/index.html:ro
  ports:
    - "${HTTP_PORT:-80}:80"
    - "${HTTPS_PORT:-443}:443"
```

## 方案 2：使用 Let's Encrypt（适合公网）

### 1. 安装 Certbot
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install certbot

# CentOS/RHEL
sudo yum install certbot
```

### 2. 获取证书
```bash
# 替换 your-domain.com 为您的域名
sudo certbot certonly --standalone -d your-domain.com
```

### 3. 配置 Nginx 使用 Let's Encrypt 证书
更新 nginx.conf 中的证书路径：
```nginx
ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
```

## 方案 3：使用反向代理（推荐）

在生产环境中，推荐使用专门的反向代理服务器（如 Nginx、Traefik）来处理 SSL/TLS，而不是在应用容器中配置。

### 使用 Traefik 示例
```yaml
# traefik-docker-compose.yml
version: '3.8'

services:
  traefik:
    image: traefik:v2.10
    command:
      - "--api.insecure=true"
      - "--providers.docker=true"
      - "--entrypoints.web.address=:80"
      - "--entrypoints.websecure.address=:443"
      - "--certificatesresolvers.myresolver.acme.tlschallenge=true"
      - "--certificatesresolvers.myresolver.acme.email=your-email@example.com"
      - "--certificatesresolvers.myresolver.acme.storage=/letsencrypt/acme.json"
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - "/var/run/docker.sock:/var/run/docker.sock:ro"
      - "./letsencrypt:/letsencrypt"
    networks:
      - datadiff-network

  # 在原有服务上添加 labels
  nginx:
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.nginx.rule=Host(`your-domain.com`)"
      - "traefik.http.routers.nginx.entrypoints=websecure"
      - "traefik.http.routers.nginx.tls.certresolver=myresolver"
```

## 注意事项

1. **内网环境**：通常不需要 HTTPS，使用 HTTP 即可
2. **生产环境**：强烈建议配置 HTTPS
3. **证书更新**：Let's Encrypt 证书需要每 90 天更新一次
4. **防火墙**：确保 443 端口已开放

## N8N 的 HTTPS 配置

如果配置了 HTTPS，需要更新 N8N 的环境变量：

```bash
# 编辑 .env
N8N_PROTOCOL=https
N8N_SECURE_COOKIE=true
WEBHOOK_URL=https://your-domain.com/

# 重启 N8N
docker-compose restart n8n
```