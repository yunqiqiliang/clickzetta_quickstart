#!/bin/bash
# Data-Diff N8N 简化部署脚本

set -e

# 定义颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 显示帮助信息
show_help() {
    echo "Data-Diff N8N 部署脚本"
    echo ""
    echo "用法: ./deploy.sh [命令]"
    echo ""
    echo "命令:"
    echo "  setup    初始化环境配置"
    echo "  start    启动所有服务"
    echo "  stop     停止所有服务"
    echo "  restart  重启所有服务"
    echo "  status   查看服务状态"
    echo "  logs     查看服务日志"
    echo "  clean    清理所有数据（危险操作）"
    echo "  help     显示此帮助信息"
}

# 检查 Docker 是否安装
check_docker() {
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}错误: Docker 未安装${NC}"
        echo "请访问 https://www.docker.com/products/docker-desktop/ 安装 Docker"
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        echo -e "${RED}错误: Docker 未运行${NC}"
        echo "请启动 Docker Desktop"
        exit 1
    fi
}

# 初始化设置
setup() {
    echo -e "${BLUE}正在初始化 Data-Diff N8N...${NC}"
    
    # 检查 .env 文件
    if [ -f .env ]; then
        echo -e "${YELLOW}警告: .env 文件已存在${NC}"
        read -p "是否覆盖现有配置？ (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "保留现有配置"
            return
        fi
    fi
    
    # 复制环境配置文件
    cp .env.example .env
    echo -e "${GREEN}✓ 已创建 .env 文件${NC}"
    
    # 生成随机密码
    generate_password() {
        openssl rand -base64 12 | tr -d "=+/" | cut -c1-16
    }
    
    # 更新密码
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/changeme/$(generate_password)/g" .env
    else
        # Linux
        sed -i "s/changeme/$(generate_password)/g" .env
    fi
    
    echo -e "${GREEN}✓ 已生成安全密码${NC}"
    echo ""
    echo -e "${YELLOW}重要提示:${NC}"
    echo "1. 请检查 .env 文件中的配置"
    echo "2. 确保端口未被占用（80, 443, 3000, 5678, 8000, 9090）"
    echo "3. 使用 './deploy.sh start' 启动服务"
}

# 启动服务
start() {
    echo -e "${BLUE}正在启动 Data-Diff N8N 服务...${NC}"
    
    check_docker
    
    # 检查 .env 文件
    if [ ! -f .env ]; then
        echo -e "${RED}错误: 未找到 .env 文件${NC}"
        echo "请先运行 './deploy.sh setup'"
        exit 1
    fi
    
    # 检查是否为首次运行
    FIRST_RUN=false
    if [ ! -f ".docker_images_downloaded" ]; then
        FIRST_RUN=true
        echo -e "${BLUE}首次启动检测：需要下载 Docker 镜像${NC}"
        echo "预计下载大小：约 2GB"
        echo "预计时间：10-20 分钟（取决于网络速度）"
        echo ""
    fi
    
    # 启动服务
    echo -e "${BLUE}正在拉取镜像并启动服务...${NC}"
    docker-compose up -d
    
    if [ "$FIRST_RUN" = true ]; then
        touch .docker_images_downloaded
    fi
    
    echo -e "${GREEN}✓ 服务正在启动${NC}"
    echo ""
    
    if [ "$FIRST_RUN" = true ]; then
        echo "⏱️  首次启动预计需要 10-20 分钟"
        echo "   包括："
        echo "   - 下载 6 个 Docker 镜像"
        echo "   - 初始化 PostgreSQL 数据库"
        echo "   - 配置 Grafana 仪表板"
        echo "   - 启动健康检查"
    else
        echo "⏱️  服务启动预计需要 2-3 分钟"
    fi
    echo ""
    echo "访问地址:"
    echo "  主页: http://localhost"
    echo "  N8N: http://localhost:5678"
    echo "  API: http://localhost:8000/docs"
    echo "  Grafana: http://localhost:3000"
    echo ""
    echo "使用 './deploy.sh status' 查看服务状态"
}

# 停止服务
stop() {
    echo -e "${BLUE}正在停止 Data-Diff N8N 服务...${NC}"
    docker-compose down
    echo -e "${GREEN}✓ 服务已停止${NC}"
}

# 重启服务
restart() {
    stop
    sleep 2
    start
}

# 查看服务状态
status() {
    echo -e "${BLUE}Data-Diff N8N 服务状态:${NC}"
    echo ""
    docker-compose ps
}

# 查看日志
logs() {
    if [ -z "$2" ]; then
        docker-compose logs -f --tail=100
    else
        docker-compose logs -f --tail=100 $2
    fi
}

# 清理数据
clean() {
    echo -e "${RED}警告: 此操作将删除所有数据！${NC}"
    read -p "确定要继续吗？ (yes/NO): " -r
    if [[ $REPLY == "yes" ]]; then
        docker-compose down -v
        echo -e "${GREEN}✓ 已清理所有数据${NC}"
    else
        echo "操作已取消"
    fi
}

# 主程序
case "$1" in
    setup)
        setup
        ;;
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        restart
        ;;
    status)
        status
        ;;
    logs)
        logs "$@"
        ;;
    clean)
        clean
        ;;
    help|"")
        show_help
        ;;
    *)
        echo -e "${RED}错误: 未知命令 '$1'${NC}"
        echo ""
        show_help
        exit 1
        ;;
esac