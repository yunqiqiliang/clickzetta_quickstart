#!/bin/bash
# Data-Diff N8N 增强版端口检查脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 检测操作系统
OS="Unknown"
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="Linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macOS"
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
    OS="Windows"
fi

# 打印函数
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# 从 .env 文件读取端口配置
load_env() {
    if [ -f .env ]; then
        # 安全地加载 .env 文件
        set -a
        source .env
        set +a
    fi
}

# 检查 Docker 容器占用的端口
check_docker_ports() {
    local port=$1
    local containers=""
    
    # 检查是否有 Docker 容器绑定了这个端口
    if command -v docker >/dev/null 2>&1; then
        # 获取所有容器的端口映射
        containers=$(docker ps --format "table {{.Names}}\t{{.Ports}}" 2>/dev/null | grep -E "(:${port}->|0\.0\.0\.0:${port}->)" | awk '{print $1}' || true)
    fi
    
    echo "$containers"
}

# 显示占用端口的进程信息
show_process_info() {
    local port=$1
    
    # 首先检查 Docker 容器
    local docker_containers=$(check_docker_ports $port)
    if [ -n "$docker_containers" ]; then
        echo "    Docker 容器占用："
        echo "$docker_containers" | sed 's/^/      - /'
    fi
    
    # 然后检查系统进程
    echo "    系统进程："
    if command -v lsof >/dev/null 2>&1; then
        # 尝试使用 sudo（如果可用）
        if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
            sudo lsof -i :$port 2>/dev/null | grep -v "^COMMAND" | head -5 | sed 's/^/    /' || echo "      无法获取详细信息"
        else
            lsof -i :$port 2>/dev/null | grep -v "^COMMAND" | head -5 | sed 's/^/    /' || echo "      无法获取详细信息（可能需要 sudo）"
        fi
    elif command -v ss >/dev/null 2>&1; then
        ss -tlnp 2>/dev/null | grep ":$port " | head -5 | sed 's/^/    /' || echo "      无法获取详细信息"
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tlnp 2>/dev/null | grep ":$port " | head -5 | sed 's/^/    /' || echo "      无法获取详细信息"
    fi
}

# 综合检查端口是否被占用
check_port_comprehensive() {
    local port=$1
    
    # 1. 首先检查 Docker 容器
    local docker_containers=$(check_docker_ports $port)
    if [ -n "$docker_containers" ]; then
        return 1  # 端口被占用
    fi
    
    # 2. 检查系统端口
    # 尝试多种方法
    
    # 方法1: netstat（最通用）
    if command -v netstat >/dev/null 2>&1; then
        if netstat -tuln 2>/dev/null | grep -E "(^tcp|^udp).*:${port}\s" >/dev/null; then
            return 1
        fi
    fi
    
    # 方法2: ss（现代 Linux）
    if command -v ss >/dev/null 2>&1; then
        if ss -tuln 2>/dev/null | grep -E ":${port}\s" >/dev/null; then
            return 1
        fi
    fi
    
    # 方法3: lsof（需要权限）
    if command -v lsof >/dev/null 2>&1; then
        # 尝试使用 sudo
        if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
            if sudo lsof -i :$port 2>/dev/null | grep -q "LISTEN"; then
                return 1
            fi
        else
            # 没有 sudo，尝试普通权限
            if lsof -i :$port 2>/dev/null | grep -q "LISTEN"; then
                return 1
            fi
        fi
    fi
    
    # 方法4: 尝试连接端口（最后的手段）
    if command -v nc >/dev/null 2>&1; then
        if nc -z localhost $port 2>/dev/null; then
            return 1
        fi
    elif command -v timeout >/dev/null 2>&1 && command -v bash >/dev/null 2>&1; then
        if timeout 1 bash -c "echo >/dev/tcp/localhost/$port" 2>/dev/null; then
            return 1
        fi
    fi
    
    return 0  # 端口可用
}

# 检查端口
check_port() {
    local port=$1
    local service=$2
    local default_port=$3
    
    # 如果端口变量为空，使用默认值
    if [ -z "$port" ]; then
        port=$default_port
    fi
    
    if check_port_comprehensive $port; then
        print_success "端口 $port ($service) 可用"
        return 0
    else
        print_error "端口 $port ($service) 已被占用"
        show_process_info $port
        return 1
    fi
}

# 主函数
main() {
    print_info "Data-Diff N8N 端口检查工具（增强版）"
    echo ""
    
    # 检查是否有 sudo 权限
    if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
        print_info "检测到 sudo 权限，将进行更详细的检查"
    else
        print_warning "无 sudo 权限，某些端口信息可能不完整"
    fi
    echo ""
    
    # 加载环境变量
    load_env
    
    # 定义需要检查的端口
    declare -A PORTS=(
        ["N8N_PORT"]="5678:N8N"
        ["API_PORT"]="8000:API"
        ["GRAFANA_PORT"]="3000:Grafana"
        ["HTTP_PORT"]="80:Nginx HTTP"
        ["PROMETHEUS_PORT"]="9090:Prometheus"
        ["POSTGRES_PORT"]="5432:PostgreSQL"
        # ["HTTPS_PORT"]="443:Nginx HTTPS"  # 默认不启用 HTTPS
    )
    
    # 检查所有端口
    local all_clear=true
    local conflicts=0
    
    print_info "检查必需端口..."
    echo ""
    
    for var in N8N_PORT API_PORT GRAFANA_PORT HTTP_PORT PROMETHEUS_PORT POSTGRES_PORT; do
        IFS=':' read -r default_port service_name <<< "${PORTS[$var]}"
        port_value="${!var:-$default_port}"
        
        if ! check_port "$port_value" "$service_name" "$default_port"; then
            all_clear=false
            ((conflicts++))
        fi
    done
    
    echo ""
    
    # 检查 Docker 是否在运行
    if command -v docker >/dev/null 2>&1 && docker ps >/dev/null 2>&1; then
        print_success "Docker 正在运行"
    else
        print_warning "Docker 未运行或无法访问"
    fi
    
    echo ""
    
    # 总结
    if [ "$all_clear" = true ]; then
        print_success "所有端口检查通过！可以开始部署。"
        echo ""
        print_info "下一步："
        echo "  1. 运行: ./deploy.sh setup"
        echo "  2. 运行: ./deploy.sh start"
        exit 0
    else
        print_error "发现 $conflicts 个端口冲突！"
        echo ""
        print_warning "解决方案："
        echo "  1. 停止占用端口的服务"
        echo "  2. 或者修改 .env 文件中的端口配置"
        echo ""
        print_info "修改端口示例："
        echo "  编辑 .env 文件，修改冲突的端口："
        echo "  API_PORT=8001          # 如果 8000 被占用"
        echo "  N8N_PORT=5679          # 如果 5678 被占用"
        echo "  GRAFANA_PORT=3001      # 如果 3000 被占用"
        echo "  PROMETHEUS_PORT=9091   # 如果 9090 被占用"
        echo "  POSTGRES_PORT=5433     # 如果 5432 被占用"
        echo "  HTTPS_PORT=8443        # 如果 443 被占用"
        exit 1
    fi
}

# 执行主函数
main