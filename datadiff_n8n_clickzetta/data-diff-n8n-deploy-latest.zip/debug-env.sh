#!/bin/bash
# 调试环境变量传递问题

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== 环境变量调试工具 ===${NC}"
echo ""

# 1. 检查 .env 文件
echo -e "${BLUE}1. 检查 .env 文件:${NC}"
if [ -f .env ]; then
    echo -e "${GREEN}✓ .env 文件存在${NC}"
    echo "   PostgreSQL 密码: $(grep POSTGRES_PASSWORD .env | cut -d= -f2)"
else
    echo -e "${RED}✗ .env 文件不存在${NC}"
    exit 1
fi
echo ""

# 2. 检查 Docker Compose 是否能读取环境变量
echo -e "${BLUE}2. Docker Compose 环境变量:${NC}"
docker-compose config | grep -A5 "DB_POSTGRESDB_PASSWORD" | head -10
echo ""

# 3. 检查运行中的容器环境变量
echo -e "${BLUE}3. 容器实际环境变量:${NC}"

# PostgreSQL 容器
echo "PostgreSQL 容器:"
POSTGRES_CONTAINER=$(docker-compose ps -q postgres 2>/dev/null)
if [ -n "$POSTGRES_CONTAINER" ]; then
    docker exec $POSTGRES_CONTAINER env | grep POSTGRES_PASSWORD || echo "未找到 POSTGRES_PASSWORD"
else
    echo -e "${RED}PostgreSQL 容器未运行${NC}"
fi
echo ""

# N8N 容器
echo "N8N 容器:"
N8N_CONTAINER=$(docker-compose ps -q n8n 2>/dev/null)
if [ -n "$N8N_CONTAINER" ]; then
    docker exec $N8N_CONTAINER env | grep DB_POSTGRESDB_PASSWORD || echo "未找到 DB_POSTGRESDB_PASSWORD"
else
    echo -e "${RED}N8N 容器未运行${NC}"
fi
echo ""

# 4. 测试数据库连接
echo -e "${BLUE}4. 测试数据库连接:${NC}"
source .env
echo "使用密码: $POSTGRES_PASSWORD"

# 尝试连接
if PGPASSWORD=$POSTGRES_PASSWORD docker-compose exec -T postgres psql -U postgres -c "SELECT 1;" >/dev/null 2>&1; then
    echo -e "${GREEN}✓ 可以使用 .env 中的密码连接 PostgreSQL${NC}"
else
    echo -e "${RED}✗ 无法使用 .env 中的密码连接 PostgreSQL${NC}"
    
    # 尝试默认密码
    if PGPASSWORD=changeme docker-compose exec -T postgres psql -U postgres -c "SELECT 1;" >/dev/null 2>&1; then
        echo -e "${YELLOW}! 但可以使用默认密码 'changeme' 连接${NC}"
        echo -e "${YELLOW}! 这说明 PostgreSQL 使用了默认密码初始化${NC}"
    fi
fi
echo ""

# 5. 建议
echo -e "${BLUE}5. 修复建议:${NC}"
if [ "$POSTGRES_PASSWORD" != "changeme" ]; then
    echo "如果 PostgreSQL 使用了默认密码初始化，您可以："
    echo "1. 停止所有服务: docker-compose down"
    echo "2. 删除数据卷: docker volume rm \$(docker volume ls -q | grep postgres_data)"
    echo "3. 重新启动: docker-compose up -d"
    echo ""
    echo "或者更新 PostgreSQL 密码："
    echo "PGPASSWORD=changeme docker-compose exec postgres psql -U postgres -c \"ALTER USER postgres PASSWORD '$POSTGRES_PASSWORD';\""
fi