#!/bin/bash
# 自动配置 HTTPS 的脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 打印函数
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检测系统
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            OS="debian"
        elif [ -f /etc/redhat-release ]; then
            OS="redhat"
        else
            OS="linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    else
        OS="unknown"
    fi
}

# 生成自签名证书
generate_self_signed_cert() {
    print_info "生成自签名证书..."
    
    # 创建证书目录
    mkdir -p ssl
    
    # 获取主机名或 IP
    if [ -z "$DOMAIN" ]; then
        # 尝试获取公网 IP
        PUBLIC_IP=$(curl -s ifconfig.me || curl -s icanhazip.com || echo "localhost")
        DOMAIN=${PUBLIC_IP}
        print_info "使用 IP 地址: $DOMAIN"
    fi
    
    # 创建证书配置文件
    cat > ssl/openssl.cnf <<EOF
[req]
distinguished_name = req_distinguished_name
req_extensions = v3_req
prompt = no

[req_distinguished_name]
C = CN
ST = State
L = City
O = Data-Diff N8N
OU = IT Department
CN = ${DOMAIN}

[v3_req]
keyUsage = keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = ${DOMAIN}
DNS.2 = localhost
DNS.3 = *.${DOMAIN}
IP.1 = 127.0.0.1
IP.2 = ${PUBLIC_IP}
EOF
    
    # 生成私钥和证书
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout ssl/nginx.key \
        -out ssl/nginx.crt \
        -config ssl/openssl.cnf \
        -extensions v3_req
    
    # 设置权限
    chmod 600 ssl/nginx.key
    chmod 644 ssl/nginx.crt
    
    print_success "自签名证书生成成功！"
    print_warning "注意：自签名证书会在浏览器中显示安全警告"
}

# 安装 Certbot
install_certbot() {
    print_info "检查 Certbot 安装..."
    
    if command -v certbot &> /dev/null; then
        print_success "Certbot 已安装"
        return 0
    fi
    
    detect_os
    
    case $OS in
        debian)
            print_info "在 Debian/Ubuntu 上安装 Certbot..."
            sudo apt-get update
            sudo apt-get install -y certbot
            ;;
        redhat)
            print_info "在 RHEL/CentOS 上安装 Certbot..."
            sudo yum install -y epel-release
            sudo yum install -y certbot
            ;;
        macos)
            print_info "在 macOS 上安装 Certbot..."
            if command -v brew &> /dev/null; then
                brew install certbot
            else
                print_error "请先安装 Homebrew"
                exit 1
            fi
            ;;
        *)
            print_error "不支持的操作系统"
            exit 1
            ;;
    esac
}

# 获取 Let's Encrypt 证书
get_letsencrypt_cert() {
    print_info "获取 Let's Encrypt 证书..."
    
    if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
        print_error "请提供域名和邮箱地址"
        echo "用法: DOMAIN=your-domain.com EMAIL=your@email.com $0 letsencrypt"
        exit 1
    fi
    
    # 停止 Nginx 以释放 80 端口
    if docker ps | grep -q datadiff-nginx; then
        print_info "临时停止 Nginx..."
        docker-compose stop nginx
    fi
    
    # 获取证书
    sudo certbot certonly --standalone \
        -d $DOMAIN \
        -d www.$DOMAIN \
        --non-interactive \
        --agree-tos \
        --email $EMAIL \
        --no-eff-email
    
    # 创建证书链接
    mkdir -p ssl
    sudo ln -sf /etc/letsencrypt/live/$DOMAIN/fullchain.pem ssl/nginx.crt
    sudo ln -sf /etc/letsencrypt/live/$DOMAIN/privkey.pem ssl/nginx.key
    
    # 设置自动续期
    setup_auto_renewal
    
    print_success "Let's Encrypt 证书获取成功！"
}

# 设置自动续期
setup_auto_renewal() {
    print_info "设置证书自动续期..."
    
    # 创建续期脚本
    cat > ssl/renew-cert.sh <<'EOF'
#!/bin/bash
certbot renew --pre-hook "docker-compose stop nginx" --post-hook "docker-compose start nginx"
EOF
    
    chmod +x ssl/renew-cert.sh
    
    # 添加 cron 任务
    (crontab -l 2>/dev/null; echo "0 3 * * * $(pwd)/ssl/renew-cert.sh >> $(pwd)/ssl/renew.log 2>&1") | crontab -
    
    print_success "自动续期已设置（每天凌晨 3 点检查）"
}

# 更新 Nginx 配置
update_nginx_config() {
    print_info "更新 Nginx 配置以支持 HTTPS..."
    
    # 备份原配置
    cp nginx.conf nginx.conf.bak
    
    # 创建 HTTPS 配置
    cat > nginx-https.conf <<'EOF'
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    # SSL Settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_stapling on;
    ssl_stapling_verify on;

    # Gzip Settings
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml application/atom+xml image/svg+xml;

    # Docker DNS
    resolver 127.0.0.11 valid=30s;

    # Upstream definitions
    upstream api_backend {
        server data-diff-api:8000;
    }

    upstream n8n_backend {
        server n8n:5678;
    }

    upstream grafana_backend {
        server grafana:3000;
    }

    # HTTP 重定向到 HTTPS
    server {
        listen 80;
        server_name _;
        return 301 https://$server_name$request_uri;
    }

    # HTTPS 服务器
    server {
        listen 443 ssl http2;
        server_name _;

        ssl_certificate /etc/nginx/ssl/nginx.crt;
        ssl_certificate_key /etc/nginx/ssl/nginx.key;

        # 安全头
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header Referrer-Policy "no-referrer-when-downgrade" always;

        # 主页
        location / {
            root /usr/share/nginx/html;
            index index.html;
            try_files $uri $uri/ /index.html;
        }

        # N8N 工作流编辑器
        location /workflow {
            return 301 /workflow/;
        }

        location /workflow/ {
            proxy_pass http://n8n_backend/;
            proxy_redirect / /workflow/;
            
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $http_connection;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto https;
            proxy_set_header X-Forwarded-Host $host;
            proxy_set_header X-Forwarded-Port 443;
            
            proxy_connect_timeout 90s;
            proxy_send_timeout 90s;
            proxy_read_timeout 90s;
            proxy_buffering off;
            proxy_request_buffering off;
            
            sub_filter_types text/html application/javascript text/javascript application/json;
            sub_filter_once off;
            sub_filter 'href="/' 'href="/workflow/';
            sub_filter 'src="/' 'src="/workflow/';
            sub_filter 'url(/' 'url(/workflow/';
            sub_filter '/rest/' '/workflow/rest/';
            sub_filter '/webhook/' '/workflow/webhook/';
            sub_filter 'BASE_PATH = "/"' 'BASE_PATH = "/workflow/"';
        }

        # API 文档和接口
        location /api {
            return 301 /api/;
        }

        location /api/ {
            proxy_pass http://api_backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto https;
            
            proxy_buffer_size 4k;
            proxy_buffers 8 4k;
            proxy_busy_buffers_size 16k;
            proxy_connect_timeout 60s;
            proxy_send_timeout 300s;
            proxy_read_timeout 300s;
        }

        # API 文档特殊处理
        location = /api/docs {
            proxy_pass http://api_backend/docs;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-Proto https;
        }

        location = /api/redoc {
            proxy_pass http://api_backend/redoc;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-Proto https;
        }

        location = /api/openapi.json {
            proxy_pass http://api_backend/openapi.json;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-Proto https;
        }

        # Grafana 监控
        location /monitor {
            return 301 /monitor/;
        }

        location /monitor/ {
            proxy_pass http://grafana_backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto https;
            
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $http_connection;
            
            sub_filter_types text/html application/javascript text/javascript;
            sub_filter_once off;
            sub_filter '"/api/' '"/monitor/api/';
            sub_filter '"/public/' '"/monitor/public/';
            sub_filter '"/avatar/' '"/monitor/avatar/';
            sub_filter 'appSubUrl":"/"' 'appSubUrl":"/monitor/"';
            sub_filter 'base href="/"' 'base href="/monitor/"';
        }

        # Prometheus 指标
        location /metrics {
            set $prometheus prometheus:9090;
            proxy_pass http://$prometheus/metrics;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-Proto https;
        }

        # 健康检查
        location /health {
            access_log off;
            default_type text/plain;
            return 200 "healthy\n";
        }

        location /api/health {
            proxy_pass http://api_backend/health;
            proxy_set_header Host $host;
            proxy_set_header X-Forwarded-Proto https;
            access_log off;
        }
    }
}
EOF
    
    print_success "Nginx HTTPS 配置已创建"
}

# 更新 docker-compose.yml
update_docker_compose() {
    print_info "更新 Docker Compose 配置..."
    
    # 使用 sed 更新配置
    sed -i.bak 's|./nginx.conf:/etc/nginx/nginx.conf:ro|./nginx-https.conf:/etc/nginx/nginx.conf:ro|' docker-compose.yml
    sed -i 's|# - "${HTTPS_PORT:-443}:443"|- "${HTTPS_PORT:-443}:443"|' docker-compose.yml
    
    # 添加 SSL 证书挂载
    sed -i '/nginx.conf:ro/a\      - ./ssl:/etc/nginx/ssl:ro' docker-compose.yml
    
    print_success "Docker Compose 配置已更新"
}

# 主菜单
show_menu() {
    echo ""
    echo "==================================="
    echo "   Data-Diff N8N HTTPS 配置工具"
    echo "==================================="
    echo "1. 使用自签名证书（推荐用于内网）"
    echo "2. 使用 Let's Encrypt 证书（需要公网域名）"
    echo "3. 使用现有证书"
    echo "4. 退出"
    echo ""
}

# 使用现有证书
use_existing_cert() {
    print_info "使用现有证书..."
    
    if [ -z "$CERT_PATH" ] || [ -z "$KEY_PATH" ]; then
        print_error "请提供证书和私钥路径"
        echo "用法: CERT_PATH=/path/to/cert.crt KEY_PATH=/path/to/key.key $0 existing"
        exit 1
    fi
    
    # 检查文件是否存在
    if [ ! -f "$CERT_PATH" ] || [ ! -f "$KEY_PATH" ]; then
        print_error "证书或私钥文件不存在"
        exit 1
    fi
    
    # 复制证书
    mkdir -p ssl
    cp "$CERT_PATH" ssl/nginx.crt
    cp "$KEY_PATH" ssl/nginx.key
    chmod 600 ssl/nginx.key
    chmod 644 ssl/nginx.crt
    
    print_success "证书已复制"
}

# 主函数
main() {
    case "${1:-menu}" in
        selfsigned)
            generate_self_signed_cert
            update_nginx_config
            update_docker_compose
            print_success "HTTPS 配置完成！请运行 'docker-compose restart nginx' 应用更改"
            ;;
        letsencrypt)
            install_certbot
            get_letsencrypt_cert
            update_nginx_config
            update_docker_compose
            print_success "HTTPS 配置完成！请运行 'docker-compose restart nginx' 应用更改"
            ;;
        existing)
            use_existing_cert
            update_nginx_config
            update_docker_compose
            print_success "HTTPS 配置完成！请运行 'docker-compose restart nginx' 应用更改"
            ;;
        menu|*)
            show_menu
            read -p "请选择选项 [1-4]: " choice
            case $choice in
                1)
                    $0 selfsigned
                    ;;
                2)
                    read -p "请输入域名: " DOMAIN
                    read -p "请输入邮箱: " EMAIL
                    export DOMAIN EMAIL
                    $0 letsencrypt
                    ;;
                3)
                    read -p "请输入证书路径: " CERT_PATH
                    read -p "请输入私钥路径: " KEY_PATH
                    export CERT_PATH KEY_PATH
                    $0 existing
                    ;;
                4)
                    exit 0
                    ;;
                *)
                    print_error "无效的选项"
                    exit 1
                    ;;
            esac
            ;;
    esac
}

# 运行主函数
main "$@"